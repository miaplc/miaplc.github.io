# Belacqua — 100 beluga sturgeons in 20 rearing tanks (recirculating aquaculture system)

A complete example plant built with MiaPLC: one PLC, two uLink I/O modules and one HMI panel, all made with
MiaConfig and the MiaPLC editors. The name is invented (bel + acqua: beautiful water, and the beluga, the largest
sturgeon).

Tested on real devices: **no** (see "Test status" at the end).

## The plant

100 beluga sturgeons (*Huso huso*), 5 per tank, average 10 kg (1 t of fish), in 20 round tanks of 3 m³
(Ø 2 m, 1 m of water), two lines of 10 tanks. All the tanks share one water loop (RAS: the water is cleaned and
sent back, only a little new water is added every day):

```
 line A: tanks 1-10   ─┐                       each tank: oxygen probe, temperature probe, oxygen valve,
 line B: tanks 11-20  ─┤                       feeder, feeder-empty, overflow and low-level floats
                       ▼
            drum filter (automatic backwash) → biofilter (2 blowers) → sump (make-up water, pH dosing)
                       ▲                                                   │
                       └── heater / chiller ← UV steriliser ← pumps P1/P2 (VFD, duty/standby, 60-120 m³/h)
```

Beluga sturgeons need cool, clean, well oxygenated water: 16–20 °C (best about 18 °C), dissolved oxygen above
7 mg/l, pH 7.0–8.0; they are bottom feeders that eat several small meals a day (about 1 % of their weight).

## Devices

| Folder | Device | Board | Address | Role |
|---|---|---|---|---|
| `belacqua_plc_001` | PLC | ESP32-EVB (Olimex) | 192.168.0.21 | program, uLink master (2 modules), HMI data, data exposure |
| `belacqua_io_002` | I/O module, line A (tanks 1-10) | ESP32-EVB (Olimex) | 192.168.0.22 | uLink module `linea` |
| `belacqua_io_003` | I/O module, line B (tanks 11-20) | ESP32-EVB (Olimex) | 192.168.0.23 | uLink module `lineb` |
| `belacqua_hmi_010` | HMI panel | ESP32-P4 10.1" touch panel | 192.168.0.20 | operator panel |

The relays of the EVB boards (GPIO 32, 33) are never used. Every EVB has its digital I/O on shift registers
(4 × 74HC165 = 32 inputs, 4 × 74HC595 = 32 outputs) and 4 analog inputs; each I/O module adds 4 × ADS1115 on I²C
(16 channels): 20 analog channels per line, one oxygen and one temperature probe per tank (4-20 mA on 165 Ω).

`belacqua.mia` is the MiaConfig configuration: «Apri configurazione…» (MiaConfig 0.1.111 or later) shows the four devices on the
left, the modules and the panel under their PLC; «Carica tutto…» puts firmware, program and panel project on the boards.

Each device folder holds its MiaConfig project (`.mia`) and the project to open in its editor: the PLC program
(`belacqua_plc_001.miaplc`, MiaPLC editor) and the panel project (`belacqua_hmi_010.miahmi`, panel editor → Importa).
For the panel menu «Progetto da USB» copy it to the root of the stick renamed to `.json`.
`tools/gen_plc.py` and `tools/gen_hmi.py` write these two files, so names, DB fields and panel variables stay equal.

## Manual

`manual/index.html` (web page, ready for the website) and `manual/belacqua-manual.pdf`: the plant, the hall layout,
the network, the electrical design with the wiring of inputs and outputs, the I/O lists, the program, the panel,
alarms, settings and commissioning. `python tools/gen_manual.py --pdf` writes both from the same lists as the program.

## PLC program

| FC | Function |
|---|---|
| 1 Clock and schedules | local time, day of the week, day/night, peak tariff, counters of the day |
| 2 Water level | sump make-up valve with hysteresis, low-low level stops pumps and heating |
| 3 Recirculation | flow target by day / night / water alert; pump speed follows the flow (5 s steps, lowest speed that gives the flow); duty/standby pumps swapped every 24 h and on a fault |
| 4 Drum filter | backwash on high water, every N minutes and every night at a set time (cheap energy) |
| 5 Biofilter and UV | blower 1 always, blower 2 by day or with a water alert, blower speed day/night; UV only with flow |
| 6 Oxygen | per tank: oxygen valve with hysteresis, low and critical oxygen; emergency aerator per line |
| 7 pH dosing | bicarbonate pulses (on / pause) only with flow, timeout alarm |
| 8 Temperature | heater and chiller with a band, wider band in the peak tariff (energy saving), interlocked |
| 9 Feeding | 8 meal times a day, fasting day, portion per tank from fish × weight × % / meals; meal skipped in a tank with low oxygen or bad temperature; tank lights per line on chosen days |
| 10 Tank alarms | alarm word per tank (O2 low, O2 critical, feeder empty, overflow, low level, temperature) |
| 11 Plant alarms | 26 latched alarms, acknowledge from the panel or push button, horn and beacon |
| 12 Tank settings | the panel edits one tank at a time (in service, modes, fish, weight) |
| 13 Statistics | running hours, backwashes, meals, feed and estimated pump energy of the day |

Every actuator has a mode: Auto, Manual ON, Manual OFF (safety interlocks stay active in manual).

## HMI panel

9 pages (1280 × 800): the 20 tanks at a glance (oxygen, temperature, what runs, alarm colour; tap a tank to set it),
tank settings, water and filters, water quality, feeding, energy and schedules, trends, alarms, statistics.
146 alarms (26 of the plant, 6 per tank), 46 trend recordings (oxygen and temperature of every tank and 6 plant
values, one sample a minute, 24 hours).

Needs the panel firmware **0.1.8 or later** (up to 64 recordings, 20 series per chart): an older panel keeps only
the first 16 recordings and 8 series per chart.

## Test status

| Part | Checked | Tested on real device |
|---|---|---|
| MiaConfig projects | `controlla`: no errors | no |
| PLC program | editor compiler: no errors, 369 networks, 30 KB, 3298 instructions per scan at most | no |
| HMI panel project | panel project checks (firmware 0.1.8 limits): valid | no |
| uLink module numbers | the program reads `ulink_ok` bit 1 for line A and bit 2 for line B: to check on the plant | no |

## Disclaimer

The Belacqua example is provided "as is", without any warranty and without any liability of its authors: see the MIT
License (`LICENSE`).

- **Not a safety controller.** MiaPLC is not certified to any functional-safety standard (such as IEC 61508,
  ISO 13849 or IEC 62061). Never use it for safety functions: emergency stops, guards and interlocks that protect
  people, burner, pressure or other safety shutdowns, life-support equipment. They need certified safety devices,
  wired independently of the PLC.
- **Hardware.** Boards such as the Olimex ESP32-EVB and the ESP32-P4 panels are development boards, not industrial
  controllers. Check their ratings (temperature, supply, EMC, isolation, approvals) for your application and protect
  inputs and outputs as needed.
- **Your responsibility.** Whoever designs, installs or runs a system with MiaPLC is responsible for it: risk
  assessment, design and wiring by qualified persons according to the laws and standards that apply where it is used,
  and tests before use. Keep PLCs, modules and panels on a protected network, never directly on the Internet.
- **No liability.** To the extent permitted by law, the authors are not liable for any damage to people, animals,
  property or data, nor for any loss of production or profit, arising from the use of this software, its examples or
  its documentation.
- **Examples are examples.** The projects, programs, panels, wiring diagrams and process values here (for example
  the water parameters and the feeding of Belacqua) are for learning and testing only: they are not a verified design
  for a real plant, nor advice on animal care. Check every value and every connection with a qualified designer before
  using any part of them.
